<?php
// public_html/config/db.php

// Definește constantele pentru conexiunea la baza de date
// Asigură-te că aceste valori corespund cu setările tale de MySQL.
// !!! IMPORTANT: Schimbă 'root' și parola goală cu credențiale sigure pentru producție!
define('DB_HOST', '192.168.0.100'); // Adresa serverului de baze de date (de obicei 'localhost' pe hosting)
define('DB_NAME', 'edomd_1'); // Numele bazei de date (trebuie să fie același cu cel creat în MySQL)
define('DB_USER', 'edomd_1'); // Numele de utilizator al bazei de date
define('DB_PASS', 'fqqAR7qsUqyUw3aRmqzk'); // Parola bazei de date
